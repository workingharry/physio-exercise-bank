import React from 'react';
import { Link } from 'wouter';
import { Exercise } from '../../types/exercise';
import { useRoutineStore } from '../../store/useRoutineStore';
import { Eye, Plus, Check, Bookmark, Play, ChevronRight, Dumbbell } from 'lucide-react';

interface Props {
  exercises: Exercise[];
  onQuickView: (exercise: Exercise) => void;
}

export const CompactTableView: React.FC<Props> = ({ exercises, onQuickView }) => {
  const { routine, addToRoutine, removeFromRoutine, bookmarks, toggleBookmark } = useRoutineStore();

  return (
    <div className="w-full bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm dark:shadow-xl transition-colors">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-slate-50 dark:bg-slate-950/90 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider text-[11px]">
              <th className="py-3.5 px-4">運動名稱 / 部位</th>
              <th className="py-3.5 px-4 hidden md:table-cell">目標主動肌</th>
              <th className="py-3.5 px-4 hidden sm:table-cell">收縮型態</th>
              <th className="py-3.5 px-4 hidden lg:table-cell">復健分期</th>
              <th className="py-3.5 px-4 hidden xl:table-cell">難度 / 動力鏈</th>
              <th className="py-3.5 px-4 hidden sm:table-cell">標準劑量</th>
              <th className="py-3.5 px-4 text-right">快捷操作</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
            {exercises.map((exercise) => {
              const isAdded = routine.some(item => item.exerciseId === exercise.id);
              const isBookmarked = bookmarks.includes(exercise.id);

              return (
                <tr
                  key={exercise.id}
                  className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition group"
                >
                  {/* Name & Region */}
                  <td className="py-3 px-4">
                    <div className="flex flex-col">
                      <div className="flex items-center gap-1.5 mb-1">
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-teal-300 border border-slate-200 dark:border-slate-700">
                          {exercise.subRegion}
                        </span>
                        {exercise.media.videoUrl && (
                          <span className="flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] bg-teal-50 text-teal-700 dark:bg-teal-950/80 dark:text-teal-400 border border-teal-200 dark:border-teal-800/60">
                            <Play className="w-2.5 h-2.5 fill-current" />
                            <span>影片</span>
                          </span>
                        )}
                      </div>
                      <Link href={`/exercise/${exercise.id}`}>
                        <span className="font-bold text-slate-900 dark:text-slate-100 hover:text-teal-600 dark:hover:text-teal-300 transition cursor-pointer text-sm line-clamp-1">
                          {exercise.name}
                        </span>
                      </Link>
                      <span className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
                        {exercise.chineseName} · {exercise.targetPathologies[0] || ''}
                      </span>
                    </div>
                  </td>

                  {/* Target Muscles */}
                  <td className="py-3 px-4 hidden md:table-cell text-slate-700 dark:text-slate-300 font-medium">
                    <div className="line-clamp-2 max-w-xs">
                      {exercise.biomechanics.primaryMuscles.join(', ') || '下肢目標肌'}
                    </div>
                  </td>

                  {/* Movement Types */}
                  <td className="py-3 px-4 hidden sm:table-cell">
                    <div className="flex flex-wrap gap-1 max-w-[140px]">
                      {exercise.movementType.slice(0, 2).map((t) => (
                        <span key={t} className="px-1.5 py-0.5 rounded text-[10px] bg-slate-100 text-cyan-800 dark:bg-slate-800/80 dark:text-cyan-300 border border-slate-200 dark:border-slate-700/80">
                          {t}
                        </span>
                      ))}
                    </div>
                  </td>

                  {/* Rehab Phase */}
                  <td className="py-3 px-4 hidden lg:table-cell text-slate-500 dark:text-slate-400 font-medium text-[11px]">
                    <span className="truncate max-w-[150px] block">
                      {exercise.rehabPhase[0]?.split(':')[0] || 'Phase 2'}
                    </span>
                  </td>

                  {/* Difficulty & Chain */}
                  <td className="py-3 px-4 hidden xl:table-cell">
                    <div className="flex items-center gap-1.5">
                      <span className="px-1.5 py-0.5 rounded text-[10px] bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                        {exercise.difficulty.split(' ')[0]}
                      </span>
                      <span className="px-1.5 py-0.5 rounded text-[10px] bg-purple-50 text-purple-700 dark:bg-slate-800/60 dark:text-purple-300 border border-purple-200 dark:border-slate-700/60">
                        {exercise.biomechanics.kineticChain.split(' ')[0]}
                      </span>
                    </div>
                  </td>

                  {/* Dosage */}
                  <td className="py-3 px-4 hidden sm:table-cell text-slate-700 dark:text-slate-300 font-medium text-[11px]">
                    <div>{exercise.dosage.sets} x {exercise.dosage.reps}</div>
                    <div className="text-[10px] text-slate-400">{exercise.dosage.frequency}</div>
                  </td>

                  {/* Actions */}
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      {/* Bookmark */}
                      <button
                        onClick={() => toggleBookmark(exercise.id)}
                        className={`p-1.5 rounded-lg border transition ${
                          isBookmarked
                            ? 'bg-amber-500/10 text-amber-600 dark:bg-amber-500/20 dark:text-amber-300 border-amber-500/40'
                            : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800/80 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-700'
                        }`}
                        title="學習書籤"
                      >
                        <Bookmark className="w-3.5 h-3.5" />
                      </button>

                      {/* Quick View Drawer */}
                      <button
                        onClick={() => onQuickView(exercise)}
                        className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold border border-slate-200 dark:border-slate-700 transition"
                        title="快速側欄預覽"
                      >
                        <Eye className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                        <span className="hidden sm:inline">預覽</span>
                      </button>

                      {/* Add to Routine */}
                      <button
                        onClick={() => {
                          if (isAdded) {
                            removeFromRoutine(exercise.id);
                          } else {
                            addToRoutine(exercise.id);
                          }
                        }}
                        className={`p-1.5 rounded-lg transition ${
                          isAdded
                            ? 'bg-teal-500/10 text-teal-700 dark:bg-teal-500/20 dark:text-teal-300 border border-teal-500/40'
                            : 'bg-teal-600 hover:bg-teal-500 text-white'
                        }`}
                        title={isAdded ? '已在處方中' : '加入處方'}
                      >
                        {isAdded ? <Check className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
